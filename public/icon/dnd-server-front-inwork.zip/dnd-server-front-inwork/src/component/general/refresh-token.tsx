import React from "react"

export const RefreshToken: React.FC<{}> = () => {
    // React.useEffect(() => {
    //     refreshToken()
    // }, [])

    return <></>
}