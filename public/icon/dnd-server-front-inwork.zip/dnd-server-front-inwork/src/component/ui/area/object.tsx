import React from 'react'

interface Props {
}


export const Object: React.FC<Props> = ({ }: Props) => {
    return (
        <div>
        </div>
    )
}
