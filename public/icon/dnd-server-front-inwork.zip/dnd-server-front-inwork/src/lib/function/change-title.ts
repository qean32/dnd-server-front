export const changeTitle = (title: string) => {
    document.title = title
}