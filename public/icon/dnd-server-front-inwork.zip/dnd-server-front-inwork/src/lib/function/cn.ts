export const cn = (...args: string[] | any[]) => {
    return args && args.join(' ')
}