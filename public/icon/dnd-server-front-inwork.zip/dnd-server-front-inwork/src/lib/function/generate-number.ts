export const generateId = () => {
    return Math.round(Math.random() * 10000)
}