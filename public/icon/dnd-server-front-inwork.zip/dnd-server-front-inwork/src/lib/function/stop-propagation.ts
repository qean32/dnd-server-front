export const stopPropagation = (e: any) => {
    e.stopPropagation()
}