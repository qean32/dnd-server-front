export { validateWordToWord } from './validate-word-to-word'
export { validateEmail } from './validete-email'
export { validateLogin } from './validete-login'
export { validatePassword } from './validete-password'