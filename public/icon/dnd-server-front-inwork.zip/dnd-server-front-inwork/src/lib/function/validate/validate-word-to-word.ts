export const validateWordToWord = (word: string, subString: string) => {
    return word.includes(subString)
}