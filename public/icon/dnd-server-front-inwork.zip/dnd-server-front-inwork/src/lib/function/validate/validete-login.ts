export const validateLogin = () => {
    return null
}