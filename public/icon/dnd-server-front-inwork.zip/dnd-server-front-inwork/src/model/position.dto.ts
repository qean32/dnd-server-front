export type positionDto = { top: number, left: number }
export type coordinateDto = { x: number, y: number }