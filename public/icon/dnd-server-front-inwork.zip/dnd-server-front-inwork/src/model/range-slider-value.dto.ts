export interface rangeSliderValueDto {
    min: number
    max: number
}