export { authSchema, type AuthFormDto } from './auth-schema'
export { registrationSchema, type RegistrationFormDto } from './registration-schema'