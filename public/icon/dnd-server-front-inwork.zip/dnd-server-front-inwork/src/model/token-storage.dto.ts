export interface tokenStorageDto {
    access: string
}