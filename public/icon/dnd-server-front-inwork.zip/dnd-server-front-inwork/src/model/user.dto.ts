export interface userDto {
    name: string
    ava: string
    email: string
    id: number
}