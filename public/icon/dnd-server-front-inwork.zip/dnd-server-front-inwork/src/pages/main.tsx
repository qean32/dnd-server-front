import { Carousel } from "../component/ui";

export const MainPage = () => {
    return (
        <main>
            <Carousel />
        </main>
    );
}